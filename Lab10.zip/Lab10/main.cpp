#include<iostream>
#include "Student.h"

int main(){
    Student PlainJane; //empty
    PlainJane.show();

    Student Abrar("Abrar", 5, 420, 1);
   // std::cout<<Abrar.grade();
    std::cout<<Abrar.getPercentage();

    Abrar.show();
    return 0;
}