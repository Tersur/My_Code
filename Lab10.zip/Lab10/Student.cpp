#include<iostream>
#include<string>
#include "Student.h"

    Student::Student(std::string n, int r, double t, int e, double pc, double pf){
        setName(n);
        setRank(r);
        setTotalScore(t);
        setEca(e);
        grade();
        perform();
    }


    void Student::setName(std::string n){
        name = n;
    }
    std::string Student::getName() const{
        return name;
    }
    void Student::setRank(int r){
        rank = r;
    }
    int Student::getRank() const{
        return rank;
    }
    void Student::setTotalScore(double t){
        total_score = t;
    }
    double Student::getTotalScore() const{
        return total_score;
    }
    void Student::setEca(int e){
        eca = e;
    }
    int Student::getEca() const{
        return eca;
    }
    double Student::getPercentage() const{
       return percentage;
    }
    double Student::getPerformance() const{
        return performance;
    }
    //displays student info
    void Student::show() const{
        using std::cout;
        using std::endl;
        cout<<"Name: "<<getName()<<endl;
        cout<<"Rank: "<<getRank()<<endl;
        cout<<"Total score: "<<getTotalScore()<<endl;
        cout<<"Eca: "<<getEca()<<endl;
        cout<<"Percentage: "<<getPercentage()<<endl;
        cout<<"Performance: "<<getPerformance()<<"\n"<<endl;
    }
    void Student::grade(){
        percentage = total_score/500.0 * 100;
    }
    void Student::perform(){
        performance = (percentage/100 + eca)/(1.0 + eca)*100;
    }