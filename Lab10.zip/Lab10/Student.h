#ifndef Student_h
#define Student_h
#include <string>
using std::string;
class Student{
private:
    std::string name;
    int rank;
    double total_score;
    int eca;
    double percentage;
    double performance;


    void grade();
    void perform();

public:
    Student(std::string n = "No Name", int r = 0, double t = 0, int e = 0, double pc = 0.0, double pf = 0.0);

    void setName(std::string n);
    std::string getName() const;
    void setRank(int r);
    int getRank() const;
    void setTotalScore(double t);
    double getTotalScore() const;
    void setEca(int e);
    int getEca() const;
    double getPercentage() const;
    double getPerformance() const;
    //displays student info
    void show() const;
};

#endif //Student_h